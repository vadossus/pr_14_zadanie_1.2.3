﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        int Capacity_obiem;
        int Value_queue;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == null)
            {
                MessageBox.Show("Вы ввели пустую строку", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                if (!int.TryParse(textBox1.Text, out Capacity_obiem))
                {
                    MessageBox.Show("Вы ввели неверный формат числа", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    Func_Stack(Capacity_obiem);
                }
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "" || textBox2.Text == null)
            {
                MessageBox.Show("Вы ввели пустую строку", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                if (!int.TryParse(textBox2.Text, out Value_queue))
                {
                    MessageBox.Show("Вы ввели неверный формат числа", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    Func_Queue(Value_queue);
                }
            }
        }
       
        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
        }

        public void Func_Stack(int capacity)
        {
            Stack<int> stack = new Stack<int>();

            for (int i = 1; i <= capacity; i++)
            {
                stack.Push(i);
            }
            listBox1.Items.Add($"Stack (размерность): {capacity}");
            while (stack.Count > 0)
            {
                int value_pop = stack.Pop();

                listBox1.Items.Add(value_pop.ToString());
            }
        }

        public void Func_Queue(int value)
        {
            Queue<int> queue = new Queue<int>();
            for (int i = 1; i <= value; i++)
            {
                queue.Enqueue(i);
            }
            listBox2.Items.Add($"Извлечение чисел из очереди (n = {value}):");
            while (queue.Count > 0)
            {
                int value_dequeue = queue.Dequeue();
                listBox2.Items.Add(value_dequeue.ToString());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox3.Text != "" && textBox3.Text != null)
            {
                if (!char.IsLetter(textBox3.Text[0]) || !char.IsPunctuation(textBox3.Text[0]) || !char.IsSymbol(textBox3.Text[0]))
                {
                    string check_bal = textBox3.Text;
                    int balance = Balance_Check(check_bal);
                    if (balance == 0)
                    {
                        MessageBox.Show("Скобки сбалансированы");
                        File.WriteAllText("zadanie2.txt", textBox3.Text);
                    }
                    else if (balance > 0)
                    {
                        MessageBox.Show($"Лишняя ( скобка в позиции: {balance}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show($"Закрывающая скобка в позиции отсутствует: {-balance}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("У вас введена пустая строка или вы написали букву в поле", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("У вас введена пустая строка","Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public int Balance_Check(string bal)
        {
            int balance = 0;
            foreach (char c in bal)
            {
                if (c == '(')
                {
                    balance++;
                }
                else if (c == ')')
                {
                    balance--;
                }
                if (balance < 0)
                {
                    return -1 * (bal.IndexOf(c) + 1);
                }
            }
            return balance;
        }
    }
}
